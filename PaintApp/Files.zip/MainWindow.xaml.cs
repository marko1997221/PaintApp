﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Diagnostics;
using PaintApp.MyClasses;

namespace PaintApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int _id=0;
        private int IdIncrement()
        {
            return _id++;
        }
        public MainWindow()
        {
            InitializeComponent();
           
        }
            
        public System.Windows.Media.SolidColorBrush SelectedBgColor { get; set; }
        public System.Windows.Media.Brush SelectedStrokeColor { get; set; }
        public int SelectedObjectToCreate { get; set; }
        public int LineWidth { get; set; } = 0;
        public object CreatingObject{ get; set; }
        public bool IsEqualLenght { get; set; }

        private List<Button> myBtnLinewidth = new List<Button>();
        private List<Button> myBtnPencilSp = new List<Button>();
        private List<System.Windows.Shapes.Rectangle> myRecBorder = new List<System.Windows.Shapes.Rectangle>();
        private List<System.Windows.Shapes.Rectangle> myRecStoke = new List<System.Windows.Shapes.Rectangle>();


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            AddBgColors();
            AddLineWidth();
            AddDrawindObjects();
            BitmapCanvas.Width = this.Width/10.6 * 8;
            BitmapCanvas.Height = this.Height/ 20.8 * 18;
            PencilDraw.Width = this.Width / 10.6 * 8;
            PencilDraw.Height = this.Height / 20.8 * 18;
            OurRectangle rectangle = new OurRectangle(1,4,new Point(1,2), new Point(1,2));
            
           
        }
       
        private List<BgColors> ReadColors(string path)
        {
            List<BgColors> bgColors = new List<BgColors>();
            var file= File.ReadAllText(path);
            var lines = file.Split("\n");
            foreach (var line in lines)
            {
                var colors = line.Split(",");
                BgColors color1= new BgColors();
                color1.Red = int.Parse(colors[0]);
                color1.Green = int.Parse(colors[1]);
                color1.Blue = int.Parse(colors[2]);
                bgColors.Add(color1);
            }
            return bgColors;
        }
        private void AddBgColors()
        {
            //in this line i am reading colors from file 
            StringBuilder path= new StringBuilder();
            path.Append(Directory.GetCurrentDirectory());
            path.Append(@"\BgColors.txt");
            List<BgColors> colors = ReadColors(path.ToString());
            //setting counter to got thrue list that i read from file
            int counter = 0;
            //starting to create first lines of colors (row)
            for (int j = 0; j < 2; j++)
            {
                //define the container that will store first row of req
                StackPanel spRow1 = new StackPanel();
                spRow1.Orientation = Orientation.Horizontal;
                spRow1.VerticalAlignment = VerticalAlignment.Center;
                //starting a loop to create req
                for (int i = 0; i < 7; i++)
                {
                    //createing new req
                    System.Windows.Shapes.Rectangle rec1 = new System.Windows.Shapes.Rectangle();
                    //staret adding prop
                    rec1.Fill = new SolidColorBrush(System.Windows.Media.Color.FromRgb(Convert.ToByte(colors[counter].Red), Convert.ToByte(colors[counter].Green), Convert.ToByte(colors[counter].Blue)));
                    rec1.Width = 50;
                    rec1.Height = 50;
                    rec1.Stroke = System.Windows.Media.Brushes.White;
                    rec1.StrokeThickness = 1;
                    //end defining prop
                    //add the created req into the list of req which i will use afterwards to change some prop
                    myRecBorder.Add(rec1);
                    // registring event that will handle the click on the req
                    rec1.MouseLeftButtonDown += Rec1_MouseLeftButtonUp;
                    //adding req to the cointainer created befour
                    spRow1.Children.Add(rec1);
                    //going to the next color of the list of bgColorw
                    counter++;
                }
                //adeding the whol cointainer to the stackpanel created into the designe tools
                SpBack.Children.Add(spRow1);
            }
            counter = 0;
            //adding the text to the stackpanel created into the designe tools
            TextBlock textForegroud = new TextBlock();
            textForegroud.Text = "Border colors:";
            SpBack.Children.Add(textForegroud);
            //reapeating the whole process from line 68
            for (int j = 0; j < 2; j++)
            {
                StackPanel spRow1 = new StackPanel();
                spRow1.Orientation = Orientation.Horizontal;
                spRow1.VerticalAlignment = VerticalAlignment.Center;
                for (int i = 0; i < 7; i++)
                {
                    System.Windows.Shapes.Rectangle rec1Stroke = new System.Windows.Shapes.Rectangle();
                    rec1Stroke.Fill = new SolidColorBrush(System.Windows.Media.Color.FromRgb(Convert.ToByte(colors[counter].Red), Convert.ToByte(colors[counter].Green), Convert.ToByte(colors[counter].Blue)));
                    rec1Stroke.Width = 50;
                    rec1Stroke.Height = 50;
                    rec1Stroke.Stroke = System.Windows.Media.Brushes.White;
                    rec1Stroke.StrokeThickness = 1;
                    myRecStoke.Add(rec1Stroke);
                    rec1Stroke.MouseLeftButtonDown += Rec1Stroke_MouseLeftButtonDown; ;
                    spRow1.Children.Add(rec1Stroke);
                    counter++;
                }
                SpBack.Children.Add(spRow1);
            }


        }
        private void AddLineWidth()
        {
            var sp1 = Directory.GetFiles(Directory.GetCurrentDirectory()+ @"\icons\LineWidth");
            StackPanel sp = new StackPanel();            
            sp.Orientation = Orientation.Horizontal;
            sp.VerticalAlignment = VerticalAlignment.Center;
            int counter = 0;
            foreach (var item in sp1)
            {
                BitmapImage img = new BitmapImage(new Uri(item));
                System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                image.Source = img;
                image.Height = 50;
                Button button = new Button();
                button.Content = image;
                button.Background = System.Windows.Media.Brushes.White;
                button.BorderBrush = System.Windows.Media.Brushes.White;
                button.Width = 120;
                button.Height = 120;
                button.Padding = new Thickness(5);
                button.Click += Button_Click;
                button.Tag = counter +1;
                myBtnLinewidth.Add(button);
                sp.Children.Add(button);
                counter++;
            }
           
            SpBrush.Children.Add(sp);
           

        }

        private void AddDrawindObjects()
        {
            var sp1 = Directory.GetFiles(Directory.GetCurrentDirectory() + @"\icons\Pencil");
            StackPanel sp = new StackPanel();
            sp.Orientation = Orientation.Horizontal;
            sp.VerticalAlignment = VerticalAlignment.Center;
            int counter = 0;
            foreach (var item in sp1)
            {
                BitmapImage img = new BitmapImage(new Uri(item));
                System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                image.Source = img;
                image.Height = 50;
                Button button1 = new Button();
                button1.Content = image;
                button1.Background = System.Windows.Media.Brushes.White;
                button1.BorderBrush = System.Windows.Media.Brushes.White;
                button1.Width = 120;
                button1.Height = 120;
                button1.Padding = new Thickness(5);
                button1.Click += Button1_Click; ;
                button1.Tag = counter + 1;
                myBtnPencilSp.Add(button1);
                sp.Children.Add(button1);
                counter++;
            }
            SpPencil.Children.Add(sp);
            var sp2 = Directory.GetFiles(Directory.GetCurrentDirectory() + @"\icons\ButtomObjectPanle");
            StackPanel sp22 = new StackPanel();
            sp22.Orientation = Orientation.Horizontal;
            sp22.VerticalAlignment = VerticalAlignment.Center;
            foreach (var item in sp2)
            {
                BitmapImage img = new BitmapImage(new Uri(item));
                System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                image.Source = img;
                image.Height = 50;
                Button button1 = new Button();
                button1.Content = image;
                button1.Background = System.Windows.Media.Brushes.White;
                button1.BorderBrush = System.Windows.Media.Brushes.White;
                button1.Width = 120;
                button1.Height = 120;
                button1.Padding = new Thickness(5);
                button1.Click += Button1_Click; ;
                button1.Tag = counter + 1;
                myBtnPencilSp.Add(button1);
                sp22.Children.Add(button1);
                counter++;
            }
            BottomBtnPanel.Children.Add(sp22);
            var sp3 = Directory.GetFiles(Directory.GetCurrentDirectory() + @"\icons\TopObjectPanel");
            StackPanel sp33 = new StackPanel();
            sp33.Orientation = Orientation.Horizontal;
            sp33.VerticalAlignment = VerticalAlignment.Center;
            foreach (var item in sp3)
            {
                BitmapImage img = new BitmapImage(new Uri(item));
                System.Windows.Controls.Image image = new System.Windows.Controls.Image();
                image.Source = img;
                image.Height = 50;
                Button button1 = new Button();
                button1.Content = image;
                button1.Background = System.Windows.Media.Brushes.White;
                button1.BorderBrush = System.Windows.Media.Brushes.White;
                button1.Width = 120;
                button1.Height = 120;
                button1.Padding = new Thickness(5);
                button1.Click += Button1_Click; ;
                button1.Tag = counter + 1;
                myBtnPencilSp.Add(button1);
                sp33.Children.Add(button1);
                counter++;
            }
           TopBtnPanel.Children.Add(sp33);

        }
        private void Button1_Click(object sender, RoutedEventArgs e)
        {
            ResetBtnPencilGroup();
            Button b1 = sender as Button;
            b1.BorderBrush = System.Windows.Media.Brushes.Black;
            b1.BorderThickness = new Thickness(1);
            if (b1.Tag != null)
            {
                switch (b1.Tag)
                {

                    case 3:
                        {
                            PencilDraw.IsEnabled = true;
                            PencilDraw.DefaultDrawingAttributes.Color = System.Windows.Media.Color.FromRgb(255, 255, 255);
                            SelectedObjectToCreate = (int)b1.Tag;
                        }
                        break;
                     case 5:
                        {
                            PencilDraw.IsEnabled = false;
                            SelectedObjectToCreate = (int)b1.Tag;
                        } 
                        break;
                    case 8:
                        {
                            PencilDraw.IsEnabled = false;
                            SelectedObjectToCreate = (int)b1.Tag;
                        }
                        break;
                    default:
                        break;
                }
                

            }

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ResetLineWidht();
            Button b1 = sender as Button;
            b1.BorderBrush = System.Windows.Media.Brushes.Black;
            b1.BorderThickness = new Thickness(1);
            if (b1.Tag!=null)
            {
                LineWidth = (int)b1.Tag*3;
            }
            PencilDraw.DefaultDrawingAttributes.Width = LineWidth;
            PencilDraw.DefaultDrawingAttributes.Height = LineWidth;

        }

        private void Rec1Stroke_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            ResertStroke();
            System.Windows.Shapes.Rectangle rec1 = sender as System.Windows.Shapes.Rectangle;
            SelectedStrokeColor = rec1.Fill;
            rec1.StrokeThickness = 5;
            BtnLoad.Background = SelectedStrokeColor;
        }

        
        private void ResertBorder()
        {
            foreach (System.Windows.Shapes.Rectangle item in myRecBorder)
            {
                item.StrokeThickness = 1;
            }
        }
        private void ResertStroke()
        {
            foreach (System.Windows.Shapes.Rectangle item in myRecStoke)
            {
                item.StrokeThickness = 1;
            }
        }
        private void ResetLineWidht()
        {
            foreach (Button item in myBtnLinewidth)
            {
                item.BorderThickness = new Thickness(0);
                item.BorderBrush = System.Windows.Media.Brushes.White;
            }
        }
        private void ResetBtnPencilGroup()
        {
            foreach (Button item in myBtnPencilSp)
            {
                item.BorderThickness = new Thickness(0);
                item.BorderBrush = System.Windows.Media.Brushes.White;
            }
        }

        private void Rec1_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ResertBorder();
            System.Windows.Shapes.Rectangle rec1= sender as System.Windows.Shapes.Rectangle;
            SelectedBgColor = rec1.Fill as SolidColorBrush;
            rec1.StrokeThickness = 5;
            PencilDraw.DefaultDrawingAttributes.Color = SelectedBgColor.Color;
        }

        private void Slider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            var slider= sender as Slider;
            int _value=(int)slider.Value;
            TextBlockZoom.Text= (100+(_value*10)).ToString()+"%";
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void TextBlock_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            TextBlockNewProject.Visibility = Visibility.Hidden;
            TextBoxNewProject.Visibility=Visibility.Visible;
            TextBoxNewProject.Text=TextBlockNewProject.Text.Trim();
            TextBoxNewProject.Focus();
        }

        private void TextBoxNewProject_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key==Key.Enter)
            {
                TextBlockNewProject.Text = TextBoxNewProject.Text.Trim();
                TextBlockNewProject.Visibility = Visibility.Visible;
                TextBoxNewProject.Visibility = Visibility.Hidden;
            }
        }

        private void BitmapCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            
            switch (SelectedObjectToCreate)
            {
                case 3:
                    break;
                case 5:
                    {
                        
                        OurLine ourLine = new OurLine(IdIncrement(), 5, e.GetPosition(BitmapCanvas), e.GetPosition(BitmapCanvas));
                        if (LineWidth!=0)
                        {
                            ourLine.LineWidth = LineWidth;
                        }
                        if (SelectedStrokeColor!=null)
                        {
                            if (!ourLine.IsFillable())
                            {
                                ourLine.StrokeColor = SelectedStrokeColor;
                            }
                        }
                        CreatingObject = ourLine.drawMe(BitmapCanvas);

                    }
                    break;
                case 8:
                    {

                        OurRectangle ourRecq = new OurRectangle(IdIncrement(), 5, e.GetPosition(BitmapCanvas), e.GetPosition(BitmapCanvas));
                        if (LineWidth != 0)
                        {
                            ourRecq.LineWidth = LineWidth;
                        }
                        if (SelectedStrokeColor != null)
                        {
                           
                          ourRecq.StrokeColor = SelectedStrokeColor;
                            
                        }
                        if (SelectedBgColor!=null)
                        {
                            if (ourRecq.IsFillable())
                            {
                                ourRecq.FillColor = SelectedBgColor;
                            }
                        }

                        CreatingObject = ourRecq.drawMe(PencilDraw);
                        Canvas.SetTop(ourRecq.CreatedRect, e.GetPosition(BitmapCanvas).Y);
                        Canvas.SetLeft(ourRecq.CreatedRect, e.GetPosition(BitmapCanvas).X);
                    }
                    break;
                default:
                    break;
            }

        }

        private void BitmapCanvas_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //we can do serialization here
            var canvas = sender as Canvas;
            switch (SelectedObjectToCreate)
            {
                case 3:
                    break;
                case 5:
                    {
                        try
                        {
                            var ourLine = CreatingObject as OurLine;
                            var creating = ourLine.CreatedLine;
                            creating.X2 = e.GetPosition(canvas).X;
                            creating.Y2 = e.GetPosition(canvas).Y;
                            var element=OurShape.ourShapes.Find((b) =>  b.GetId() == ourLine.GetId());
                            element.SetEndPoint(new Point(creating.X2, creating.Y2));
                            CreatingObject = null;
                        }
                        catch (Exception)
                        {
                           
                        }
                    }
                    break;
                case 8:
                    {
                        try
                        {
                            if (IsEqualLenght)
                            {
                                var ourRecq = CreatingObject as OurRectangle;
                                var creating = ourRecq.CreatedRect;
                                Point rez = CalculateSquare(ourRecq.GetStartPoint(), e.GetPosition(canvas));
                                if (creating != null)
                                {
                                    creating.Width = rez.X;
                                    creating.Height = rez.Y;
                                }
                                var element = OurShape.ourShapes.Find((b) => b.GetId() == ourRecq.GetId());
                                element.SetEndPoint(new Point(element.GetStartPoint().X + rez.X, element.GetStartPoint().Y + rez.Y));
                                CreatingObject = null;
                            }
                            else
                            {
                                var ourRecq = CreatingObject as OurRectangle;
                                var creating = ourRecq.CreatedRect;
                                Point rez = CalculateRect(ourRecq.GetStartPoint(), e.GetPosition(canvas));
                                if (creating != null)
                                {
                                    creating.Width = rez.X;
                                    creating.Height = rez.Y;
                                }
                                var element = OurShape.ourShapes.Find((b) => b.GetId() == ourRecq.GetId());
                                element.SetEndPoint(e.GetPosition(canvas));
                               
                                CreatingObject = null;
                            }
                           
                        }
                        catch (Exception)
                        {

                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void BitmapCanvas_MouseMove(object sender, MouseEventArgs e)
        {
            var canvas = sender as Canvas;
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                switch (SelectedObjectToCreate)
                {
                    case 3:
                        break;
                    case 5:
                        {
                            if (CreatingObject!=null)
                            {
                                var ourLine = CreatingObject as OurLine;
                                var creating = ourLine.CreatedLine;
                                if (creating != null)
                                {
                                    creating.X2 = e.GetPosition(canvas).X;
                                    creating.Y2 = e.GetPosition(canvas).Y;
                                }
                            }
                           
                        }
                        break;
                    case 8:
                        {
                            if (IsEqualLenght)
                            {
                                if (CreatingObject != null)
                                {
                                    var ourRecq = CreatingObject as OurRectangle;
                                    var creating = ourRecq.CreatedRect;
                                    Point rez = CalculateSquare(ourRecq.GetStartPoint(), e.GetPosition(canvas));
                                    if (creating != null)
                                    {
                                        creating.Width = rez.X;
                                        creating.Height = rez.Y;
                                    }
                                }
                            }
                            else
                            {
                                if (CreatingObject != null)
                                {
                                    var ourRecq = CreatingObject as OurRectangle;
                                    var creating = ourRecq.CreatedRect;
                                    Point rez = CalculateRect(ourRecq.GetStartPoint(), e.GetPosition(canvas));
                                    if (creating != null)
                                    {
                                        creating.Width = rez.X;
                                        creating.Height = rez.Y;
                                    }
                                }
                            }
                            

                        }
                        break;
                    default:
                        break;
                }
            }

        }
        private Point CalculateRect(Point _start,Point _current)
        {
            double _width = 0;
            double _height = 0;
            if (_current.X>_start.X)
            {
                _width = _current.X - _start.X;
            }
            else
            {
                _width = Math.Abs(_current.X - _start.X);
            }
            if (_current.Y > _start.Y)
            {
                _height = _current.Y - _start.Y;
            }
            else
            {
                _height =Math.Abs(_current.Y - _start.Y);
            }
            return new Point(_width, _height);
        }
        private Point CalculateSquare(Point _start, Point _current)
        {
            double _width = 0;
            if (_current.X > _start.X)
            {
                _width = _current.X - _start.X;
            }
            else
            {
                _width = Math.Abs(_current.X - _start.X);
            }
           
            return new Point(_width, _width);
        }

        private void BitmapCanvas_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.LeftShift)
            {
                IsEqualLenght = true;
            }
            else
            {
                IsEqualLenght = false;
            }
        }
    }
}
