﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaintApp.MyClasses
{
    public class OurArrow : OurLine
    {
        public OurArrow(int id, int type, Point start, Point end) : base(id, type, start, end)
        {
        }
        public override void deleteMe(int index)
        {
           
        }
        public override object drawMe(object container)
        {
           return base.drawMe(container);
        }
        public override bool IsFillable()
        {
           return false;
        }
       
    }
}
