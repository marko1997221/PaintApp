﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaintApp.MyClasses
{
    public class OurEllipse : OurShape
    {
        public OurEllipse(int id, int type, Point start, Point end) : base(id, type, start, end)
        {
        }
        public override void deleteMe(int index)
        {
            base.deleteMe(index);
        }
        public override object drawMe(object container)
        {
           return base.drawMe(container);
        }
        //finish
        public override bool IsFillable()
        {
            return true;
        }
       
    }
}
