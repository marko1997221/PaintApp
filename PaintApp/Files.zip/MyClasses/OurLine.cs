﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Shapes;
using System.Windows.Media;

namespace PaintApp.MyClasses
{
    public class OurLine : OurShape
    {
        public double LineWidth { get; set; } = 1;
        //public static List<OurLine> OurLines = new List<OurLine>();
        public Line CreatedLine;
        public Brush StrokeColor { get; set; } = Brushes.Black;

        public OurLine(int id, int _type, Point start, Point end) : base(id, _type, start, end)
        {
            CreatedLine = new Line();
            LineWidth = 1;
            StrokeColor = Brushes.Black;
        }
        public OurLine(int id, int _type, Point start, Point end,double _lineWidth) : base(id, _type, start, end)
        {
            CreatedLine = new Line();
            LineWidth = _lineWidth;
        }
        public override void deleteMe(int index)
        {
            ourShapes.RemoveAt(index);
        }
        
        public override object drawMe(object container)
        {
            CreatedLine = new Line();
            CreatedLine.X1 = GetStartPoint().X;
            CreatedLine.Y1 = GetStartPoint().Y;
            CreatedLine.X2 = GetEndPoint().X;
            CreatedLine.Y2= GetEndPoint().Y;
            CreatedLine.Stroke = StrokeColor;
            CreatedLine.StrokeThickness = LineWidth;
            var canvasTemp = container as Canvas;
            AddToList(this);
            canvasTemp.Children.Add(CreatedLine);
            return this;
        }
        public override bool IsFillable()
        {
            return false;
        }
        

    } 

}

