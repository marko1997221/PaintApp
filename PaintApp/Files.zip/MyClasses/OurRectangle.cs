﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Windows.Controls;

namespace PaintApp.MyClasses
{
    public class OurRectangle : OurLine
    {
        
        //public static List<OurLine> OurLines = new List<OurLine>();
        public Rectangle CreatedRect;
        public Brush FillColor { get; set; } = Brushes.White;
        public event EventHandler KeyDown;
        public OurRectangle(int id, int type, Point start, Point end) : base(id, type, start, end)
        {
            CreatedRect = new Rectangle();
            LineWidth = 1;
            StrokeColor = Brushes.Black;
            FillColor = Brushes.White;
        }
        public override void deleteMe(int index)
        {
           base.drawMe(index);
        }
        public override object drawMe(object container)
        {
            CreatedRect = new Rectangle();
            CreatedRect.StrokeThickness=LineWidth;
            CreatedRect.Fill = FillColor;
            CreatedRect.Stroke = StrokeColor;
            CreatedRect.Height = 0;
            CreatedRect.Width= 0;
            var canvasTemp = container as InkCanvas;
            AddToList(this);
            canvasTemp.Children.Add(CreatedRect);
            return this;
        }

        //finish
        public override bool IsFillable()
        {
            return true;
        }
    }
}
