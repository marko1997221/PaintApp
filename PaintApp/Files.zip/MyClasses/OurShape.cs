﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PaintApp.MyClasses
{
    public class OurShape : Ashape
    {
        private int _id;
        private Point _start  = new Point(0,0);
        private Point _end = new Point(0, 0);
        private int _type;
        public static List<OurShape> ourShapes = new List<OurShape>();
        public OurShape(int id,int type,Point start,Point end)
        {
            _id = id;
            _type = type;
            _start = start;
            _end = end;
        }
        public Point GetStartPoint()
        {
            return _start;
        }
        public Point GetEndPoint()
        {
            return _end;
        }
        public void SetStartPoint(Point p)
        {
            if (p != null)
            {
                _start= p;
            }
        }
        public void SetEndPoint(Point p)
        {
            if (p != null)
            {
                _end = p;
            }
        }
        public int GetId()
        {
            return this._id;
        }
        public override void deleteMe(int index)
        {
            
        }

        public override bool IsFillable()
        {
            return false;
        }

        public override object drawMe(object container)
        {
            throw new NotImplementedException();
        }
        public void AddToList( OurShape element)
        {
            ourShapes.Add(element);
        }
    }
}
